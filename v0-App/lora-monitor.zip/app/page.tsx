"use client"

import { useState } from "react"
import SignalDisplay from "@/components/signal-display"
import SerialConnect from "@/components/serial-connect"
import RecordingControls from "@/components/recording-controls"

export default function Home() {
  const [port, setPort] = useState<SerialPort | null>(null)
  const [isConnected, setIsConnected] = useState(false)
  const [rssi, setRssi] = useState<number | null>(null)
  const [snr, setSnr] = useState<number | null>(null)
  const [serialData, setSerialData] = useState<string[]>([])
  const [isRecording, setIsRecording] = useState(false)
  const [recordedData, setRecordedData] = useState<string[]>([])

  // 기록 시작
  const startRecording = () => {
    setIsRecording(true)
    setRecordedData([])
  }

  // 기록 중지
  const stopRecording = () => {
    setIsRecording(false)
  }

  // 새 데이터가 들어올 때 기록 중이면 저장
  const handleNewData = (data: string) => {
    setSerialData((prev) => [...prev, data])

    // 기록 중이면 데이터 저장
    if (isRecording) {
      setRecordedData((prev) => [...prev, data])
    }
  }

  return (
    <main className="flex min-h-screen flex-col items-center p-4 md:p-8">
      <h1 className="text-2xl font-bold mb-8">LoRa 모듈 모니터링</h1>

      <SerialConnect
        port={port}
        setPort={setPort}
        isConnected={isConnected}
        setIsConnected={setIsConnected}
        setRssi={setRssi}
        setSnr={setSnr}
        onNewData={handleNewData}
      />

      <div className="w-full max-w-2xl mt-8">
        <SignalDisplay rssi={rssi} snr={snr} />

        <div className="mt-8">
          <RecordingControls
            isRecording={isRecording}
            startRecording={startRecording}
            stopRecording={stopRecording}
            recordedData={recordedData}
            isConnected={isConnected}
          />
        </div>
      </div>
    </main>
  )
}
