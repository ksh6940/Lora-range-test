"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Play, Square, FileJson, FileText, FileSpreadsheet, AlertCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface RecordingControlsProps {
  isRecording: boolean
  startRecording: () => void
  stopRecording: () => void
  recordedData: string[]
  isConnected: boolean
}

export default function RecordingControls({
  isRecording,
  startRecording,
  stopRecording,
  recordedData,
  isConnected,
}: RecordingControlsProps) {
  const { toast } = useToast()
  const [recordingTime, setRecordingTime] = useState(0)
  const [fileName, setFileName] = useState("lora-logs")

  // 타이머 관리
  useState(() => {
    let interval: NodeJS.Timeout | null = null

    if (isRecording) {
      interval = setInterval(() => {
        setRecordingTime((prev) => prev + 1)
      }, 1000)
    } else {
      if (interval) clearInterval(interval)
      setRecordingTime(0)
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isRecording])

  // 시간 포맷팅 (초 -> MM:SS)
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
      .toString()
      .padStart(2, "0")
    const secs = (seconds % 60).toString().padStart(2, "0")
    return `${mins}:${secs}`
  }

  // 텍스트 파일로 다운로드
  const downloadAsText = () => {
    if (recordedData.length === 0) {
      toast({
        title: "다운로드 실패",
        description: "저장된 데이터가 없습니다.",
        variant: "destructive",
      })
      return
    }

    const blob = new Blob([recordedData.join("\n")], { type: "text/plain" })
    downloadFile(blob, "txt")
  }

  // CSV 파일로 다운로드
  const downloadAsCSV = () => {
    if (recordedData.length === 0) {
      toast({
        title: "다운로드 실패",
        description: "저장된 데이터가 없습니다.",
        variant: "destructive",
      })
      return
    }

    // RSSI와 SNR 데이터 추출
    const parsedData = recordedData.map((line) => {
      const rssiMatch = line.match(/RSSI:\s*(-?\d+)/)
      const snrMatch = line.match(/SNR:\s*(-?\d+\.?\d*)/)
      const timestamp = new Date().toISOString()

      return {
        timestamp,
        rssi: rssiMatch ? rssiMatch[1] : "",
        snr: snrMatch ? snrMatch[1] : "",
        rawData: line.trim(),
      }
    })

    // CSV 헤더와 데이터 생성
    const csvHeader = "Timestamp,RSSI,SNR,Raw Data\n"
    const csvData = parsedData
      .map((item) => `${item.timestamp},${item.rssi},${item.snr},"${item.rawData.replace(/"/g, '""')}"`)
      .join("\n")

    const blob = new Blob([csvHeader + csvData], { type: "text/csv" })
    downloadFile(blob, "csv")
  }

  // JSON 파일로 다운로드
  const downloadAsJSON = () => {
    if (recordedData.length === 0) {
      toast({
        title: "다운로드 실패",
        description: "저장된 데이터가 없습니다.",
        variant: "destructive",
      })
      return
    }

    // RSSI와 SNR 데이터 추출
    const parsedData = recordedData.map((line) => {
      const rssiMatch = line.match(/RSSI:\s*(-?\d+)/)
      const snrMatch = line.match(/SNR:\s*(-?\d+\.?\d*)/)

      return {
        timestamp: new Date().toISOString(),
        rssi: rssiMatch ? Number(rssiMatch[1]) : null,
        snr: snrMatch ? Number(snrMatch[1]) : null,
        rawData: line.trim(),
      }
    })

    const blob = new Blob([JSON.stringify(parsedData, null, 2)], { type: "application/json" })
    downloadFile(blob, "json")
  }

  // 파일 다운로드 공통 함수
  const downloadFile = (blob: Blob, extension: string) => {
    const finalFileName = fileName.trim() || "lora-logs"
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${finalFileName}.${extension}`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast({
      title: "다운로드 완료",
      description: `${finalFileName}.${extension} 파일이 다운로드되었습니다.`,
    })
  }

  return (
    <Card className="w-full">
      <CardContent className="p-4">
        <div className="flex flex-col gap-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              {isRecording ? (
                <Button variant="destructive" onClick={stopRecording} disabled={!isConnected}>
                  <Square className="h-4 w-4 mr-2" />
                  기록 중지
                </Button>
              ) : (
                <Button variant="default" onClick={startRecording} disabled={!isConnected}>
                  <Play className="h-4 w-4 mr-2" />
                  기록 시작
                </Button>
              )}

              {isRecording && (
                <span className="text-sm font-mono bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 px-2 py-1 rounded-md">
                  {formatTime(recordingTime)}
                </span>
              )}
            </div>

            {!isConnected && (
              <div className="text-sm text-muted-foreground flex items-center">
                <AlertCircle className="h-4 w-4 mr-1" />
                시리얼 포트에 연결하세요
              </div>
            )}
          </div>

          <div className="flex items-center gap-2 mt-2">
            <label htmlFor="file-name" className="text-sm font-medium w-24">
              파일명:
            </label>
            <input
              id="file-name"
              type="text"
              value={fileName}
              onChange={(e) => setFileName(e.target.value)}
              placeholder="파일명 입력"
              className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
            />
          </div>

          <div className="grid grid-cols-3 gap-2">
            <Button
              variant="outline"
              onClick={downloadAsText}
              disabled={recordedData.length === 0}
              className="flex flex-col items-center py-6"
            >
              <FileText className="h-8 w-8 mb-2" />
              <span>텍스트 (.txt)</span>
            </Button>

            <Button
              variant="outline"
              onClick={downloadAsCSV}
              disabled={recordedData.length === 0}
              className="flex flex-col items-center py-6"
            >
              <FileSpreadsheet className="h-8 w-8 mb-2" />
              <span>CSV (.csv)</span>
            </Button>

            <Button
              variant="outline"
              onClick={downloadAsJSON}
              disabled={recordedData.length === 0}
              className="flex flex-col items-center py-6"
            >
              <FileJson className="h-8 w-8 mb-2" />
              <span>JSON (.json)</span>
            </Button>
          </div>

          <div className="text-sm text-center text-muted-foreground">
            {recordedData.length > 0 ? `${recordedData.length}개의 데이터 포인트가 기록됨` : "기록된 데이터가 없습니다"}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
