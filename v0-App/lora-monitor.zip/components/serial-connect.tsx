"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { RefreshCw } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface SerialConnectProps {
  port: SerialPort | null
  setPort: (port: SerialPort | null) => void
  isConnected: boolean
  setIsConnected: (isConnected: boolean) => void
  setRssi: (rssi: number | null) => void
  setSnr: (snr: number | null) => void
  onNewData: (data: string) => void
}

export default function SerialConnect({
  port,
  setPort,
  isConnected,
  setIsConnected,
  setRssi,
  setSnr,
  onNewData,
}: SerialConnectProps) {
  const [reader, setReader] = useState<ReadableStreamDefaultReader | null>(null)
  const [keepReading, setKeepReading] = useState(false)
  const { toast } = useToast()

  // 시리얼 포트 연결
  const connectSerial = async () => {
    if (!navigator.serial) {
      toast({
        title: "오류",
        description: "Web Serial API가 지원되지 않는 브라우저입니다.",
        variant: "destructive",
      })
      return
    }

    try {
      const port = await navigator.serial.requestPort()
      await port.open({ baudRate: 9600 })

      setPort(port)
      setIsConnected(true)
      toast({
        title: "연결 성공",
        description: "시리얼 포트에 연결되었습니다.",
      })

      const reader = port.readable.getReader()
      setReader(reader)
      setKeepReading(true)
      readSerialData(reader)
    } catch (error) {
      console.error("시리얼 연결 오류:", error)
      toast({
        title: "연결 실패",
        description: "시리얼 포트 연결에 실패했습니다.",
        variant: "destructive",
      })
    }
  }

  // 시리얼 포트 연결 해제
  const disconnectSerial = async () => {
    if (reader) {
      setKeepReading(false)
      reader.releaseLock()
      setReader(null)
    }

    if (port) {
      await port.close()
      setPort(null)
    }

    setIsConnected(false)
    toast({
      title: "연결 해제",
      description: "시리얼 포트 연결이 해제되었습니다.",
    })
  }

  // 시리얼 데이터 읽기
  const readSerialData = async (reader: ReadableStreamDefaultReader) => {
    try {
      while (keepReading) {
        const { value, done } = await reader.read()
        if (done) {
          break
        }

        // 데이터 처리
        const decoder = new TextDecoder()
        const text = decoder.decode(value)

        // 새 데이터 콜백 호출
        onNewData(text)

        // RSSI 및 SNR 값 추출
        parseLoRaData(text)
      }
    } catch (error) {
      console.error("시리얼 데이터 읽기 오류:", error)
    } finally {
      reader.releaseLock()
    }
  }

  // LoRa 데이터 파싱 (RSSI 및 SNR 추출)
  const parseLoRaData = (data: string) => {
    // RSSI 추출 (예: "RSSI: -75")
    const rssiMatch = data.match(/RSSI:\s*(-?\d+)/)
    if (rssiMatch && rssiMatch[1]) {
      setRssi(Number.parseInt(rssiMatch[1]))
    }

    // SNR 추출 (예: "SNR: 9.5")
    const snrMatch = data.match(/SNR:\s*(-?\d+\.?\d*)/)
    if (snrMatch && snrMatch[1]) {
      setSnr(Number.parseFloat(snrMatch[1]))
    }
  }

  // 컴포넌트 언마운트 시 연결 해제
  useEffect(() => {
    return () => {
      if (reader) {
        setKeepReading(false)
        reader.releaseLock()
      }
      if (port && port.readable) {
        port.close().catch(console.error)
      }
    }
  }, [port, reader])

  return (
    <div className="flex gap-2">
      {!isConnected ? (
        <Button onClick={connectSerial}>시리얼 포트 연결</Button>
      ) : (
        <Button variant="destructive" onClick={disconnectSerial}>
          연결 해제
        </Button>
      )}
      <Button variant="outline" size="icon" onClick={connectSerial} disabled={isConnected}>
        <RefreshCw className="h-4 w-4" />
      </Button>
    </div>
  )
}
