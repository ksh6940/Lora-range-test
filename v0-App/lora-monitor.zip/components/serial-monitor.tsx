"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { X, Download } from "lucide-react"

interface SerialMonitorProps {
  serialData: string[]
  filter: string
  setFilter: (filter: string) => void
}

export default function SerialMonitor({ serialData, filter, setFilter }: SerialMonitorProps) {
  const [activeTab, setActiveTab] = useState("all")

  // 필터링된 데이터
  const filteredData = serialData.filter((data) => {
    if (!filter) return true
    return data.toLowerCase().includes(filter.toLowerCase())
  })

  // RSSI 데이터만 필터링
  const rssiData = serialData.filter((data) => data.toLowerCase().includes("rssi"))

  // SNR 데이터만 필터링
  const snrData = serialData.filter((data) => data.toLowerCase().includes("snr"))

  // 로그 내보내기
  const exportLogs = () => {
    const dataToExport = activeTab === "all" ? filteredData : activeTab === "rssi" ? rssiData : snrData

    const blob = new Blob([dataToExport.join("\n")], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `lora-logs-${new Date().toISOString()}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <Card className="w-full">
      <CardContent className="p-4">
        <div className="flex items-center gap-2 mb-4">
          <Input placeholder="필터..." value={filter} onChange={(e) => setFilter(e.target.value)} className="flex-1" />
          {filter && (
            <Button variant="ghost" size="icon" onClick={() => setFilter("")} className="h-10 w-10">
              <X className="h-4 w-4" />
            </Button>
          )}
          <Button variant="outline" size="icon" onClick={exportLogs} className="h-10 w-10">
            <Download className="h-4 w-4" />
          </Button>
        </div>

        <Tabs defaultValue="all" onValueChange={setActiveTab}>
          <TabsList className="mb-2">
            <TabsTrigger value="all">전체</TabsTrigger>
            <TabsTrigger value="rssi">RSSI</TabsTrigger>
            <TabsTrigger value="snr">SNR</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="mt-0">
            <div className="bg-muted p-2 rounded-md h-64 overflow-y-auto font-mono text-sm">
              {filteredData.length > 0 ? (
                filteredData.map((data, index) => (
                  <div key={index} className="whitespace-pre-wrap break-all mb-1">
                    {data}
                  </div>
                ))
              ) : (
                <div className="text-muted-foreground text-center mt-4">데이터가 없습니다</div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="rssi" className="mt-0">
            <div className="bg-muted p-2 rounded-md h-64 overflow-y-auto font-mono text-sm">
              {rssiData.length > 0 ? (
                rssiData.map((data, index) => (
                  <div key={index} className="whitespace-pre-wrap break-all mb-1">
                    {data}
                  </div>
                ))
              ) : (
                <div className="text-muted-foreground text-center mt-4">RSSI 데이터가 없습니다</div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="snr" className="mt-0">
            <div className="bg-muted p-2 rounded-md h-64 overflow-y-auto font-mono text-sm">
              {snrData.length > 0 ? (
                snrData.map((data, index) => (
                  <div key={index} className="whitespace-pre-wrap break-all mb-1">
                    {data}
                  </div>
                ))
              ) : (
                <div className="text-muted-foreground text-center mt-4">SNR 데이터가 없습니다</div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
