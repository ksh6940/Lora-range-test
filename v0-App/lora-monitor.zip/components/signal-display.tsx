"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Wifi, WifiOff } from "lucide-react"

interface SignalDisplayProps {
  rssi: number | null
  snr: number | null
}

export default function SignalDisplay({ rssi, snr }: SignalDisplayProps) {
  // RSSI 신호 강도에 따른 색상 결정
  const getRssiColor = (rssi: number | null) => {
    if (rssi === null) return "text-gray-400"
    if (rssi > -70) return "text-green-500"
    if (rssi > -90) return "text-yellow-500"
    return "text-red-500"
  }

  // SNR 값에 따른 색상 결정
  const getSnrColor = (snr: number | null) => {
    if (snr === null) return "text-gray-400"
    if (snr > 5) return "text-green-500"
    if (snr > 0) return "text-yellow-500"
    return "text-red-500"
  }

  // 신호 강도에 따른 WiFi 아이콘 렌더링
  const renderWifiIcon = () => {
    if (rssi === null) {
      return <WifiOff className="h-24 w-24 text-gray-400" />
    }

    // 신호 강도에 따라 다른 아이콘 표시
    if (rssi > -70) {
      // 강한 신호 (3-4 막대)
      return (
        <div className="relative">
          <Wifi className="h-24 w-24 text-green-500" strokeWidth={1.5} />
          <div className="absolute inset-0 flex items-center justify-center">
            <Wifi className="h-16 w-16 text-green-500" strokeWidth={2.5} />
          </div>
        </div>
      )
    } else if (rssi > -90) {
      // 중간 신호 (2 막대)
      return (
        <div className="relative">
          <Wifi className="h-24 w-24 text-yellow-500" strokeWidth={1.5} />
          <div className="absolute inset-0 flex items-center justify-center">
            <Wifi className="h-12 w-12 text-yellow-500" strokeWidth={2.5} />
          </div>
        </div>
      )
    } else {
      // 약한 신호 (1 막대)
      return <Wifi className="h-24 w-24 text-red-500" strokeWidth={1.5} />
    }
  }

  return (
    <Card className="w-full">
      <CardContent className="flex flex-col items-center justify-center p-6">
        {renderWifiIcon()}

        <div className="mt-4 text-center">
          <h2 className={`text-4xl font-bold ${getRssiColor(rssi)}`}>{rssi !== null ? `${rssi} dBm` : "-- dBm"}</h2>
          <p className={`text-lg mt-2 ${getSnrColor(snr)}`}>SNR: {snr !== null ? `${snr} dB` : "--"}</p>
        </div>
      </CardContent>
    </Card>
  )
}
